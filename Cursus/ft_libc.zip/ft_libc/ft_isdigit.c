/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gamercha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/14 19:58:16 by gamercha          #+#    #+#             */
/*   Updated: 2026/01/14 19:58:20 by gamercha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <ctype.h>
#include <stdio.h>

int ft_isdigit(int i)
{
    if(i>=30 && i<=57)
        return 1;
    else
        return 0;
}
// int main ()
// {
//         printf("%i\n", ft_isdigit('a'));
//         printf("%i\n", isdigit('d'));
// }