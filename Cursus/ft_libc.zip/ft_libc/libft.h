/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gamercha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/18 18:58:30 by gamercha          #+#    #+#             */
/*   Updated: 2026/01/18 18:59:10 by gamercha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef LIBFT_H
#define LIBFT_H
#include <stdlib.h>
#include <stddef.h>

int ft_isalpha(int i);
int ft_isdigit(int i);
int	ft_isalnum(int i);
int ft_isascii(int i);

#endif
